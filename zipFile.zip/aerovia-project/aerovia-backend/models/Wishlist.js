import mongoose from 'mongoose';

const wishlistSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    itemType: {
      type: String,
      enum: ['destination', 'flight', 'hotel', 'package', 'deal'],
      required: true,
    },
    itemId: {
      type: String,
      required: true,
    },
    // Store a snapshot of the item for display
    snapshot: {
      name: String,
      image: String,
      price: Number,
      tag: String,
      country: String,
    },
  },
  { timestamps: true }
);

// Ensure a user can't save the same item twice
wishlistSchema.index({ user: 1, itemId: 1 }, { unique: true });

export default mongoose.model('Wishlist', wishlistSchema);
