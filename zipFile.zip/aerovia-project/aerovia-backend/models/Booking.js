import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    type: {
      type: String,
      enum: ['flight', 'hotel', 'bus', 'package'],
      required: true,
    },
    // Flight details
    from: { type: String },
    to: { type: String },
    flightCode: { type: String },
    airline: { type: String },
    departure: { type: String },
    arrival: { type: String },
    duration: { type: String },

    // Common
    travelDate: { type: String },
    returnDate: { type: String },
    passengers: { type: Number, default: 1 },
    extras: { type: [String], default: [] },

    // Pricing
    basePrice: { type: Number, required: true },
    totalPrice: { type: Number, required: true },

    // Status
    status: {
      type: String,
      enum: ['confirmed', 'upcoming', 'cancelled', 'completed'],
      default: 'confirmed',
    },

    // Destination info (for display)
    destinationName: { type: String },
    destinationImage: { type: String },
    hotel: { type: String },
  },
  { timestamps: true }
);

export default mongoose.model('Booking', bookingSchema);
