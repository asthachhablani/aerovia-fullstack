import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';

const router = express.Router();

const SYSTEM_PROMPT = `You are the Aerovia AI Concierge — an elite travel intelligence system for the Aerovia travel booking platform. Your personality:
- Speak like a knowledgeable, well-travelled editorial writer, not a chatbot
- Be concise but evocative. Use short, punchy sentences mixed with longer editorial ones
- Give specific, confident recommendations with price estimates in Indian Rupees (₹)
- Reference real destinations, airlines, hotels and experiences
- If someone asks about flights, hotels, packages or travel from India, be specific
- Use bold with **text** for destination names and key facts
- Keep responses under 150 words unless asked for detail
- Never say "I'm just an AI" — stay in character as a premium travel concierge
- Always end with a concrete next suggestion or question to move the conversation forward
- Aerovia serves travellers primarily from India

Aerovia offers: Flights, Hotels, Bus tickets, Curated Travel Packages, Flash Deals, and AI-powered trip planning.`;

// POST /api/chat
router.post('/', async (req, res) => {
  try {
    const { messages } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ success: false, message: 'Messages array is required.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ success: false, message: 'Gemini API key not configured.' });
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

    // Build Gemini history (all messages except the last user message)
    const history = [];
    const allMessages = [...messages];
    const lastUserMessage = allMessages.pop();

    for (const msg of allMessages) {
      history.push({
        role: msg.role === 'ai' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      });
    }

    // Start chat with system prompt injected as initial model context
    const chat = model.startChat({
      history: [
        { role: 'user', parts: [{ text: 'Who are you?' }] },
        { role: 'model', parts: [{ text: SYSTEM_PROMPT }] },
        ...history,
      ],
    });

    const result = await chat.sendMessage(lastUserMessage.content);
    const responseText = result.response.text();

    res.json({ success: true, reply: responseText });
  } catch (err) {
    console.error('[chat error]', err.message);
    res.status(500).json({
      success: false,
      message: 'AI concierge temporarily unavailable.',
      reply: "I'm having a moment of signal loss. Try again in a few seconds — I'll be back with recommendations.",
    });
  }
});

export default router;
